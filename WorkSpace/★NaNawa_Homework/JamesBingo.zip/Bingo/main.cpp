#include <iostream>
#include <time.h>
#include <Windows.h>

int iBingo = 0;
int iAIBingo = 0;

int Player[25] = {};
int AI[25] = {};

int iSelectMode = 0;
int iInput = 0;

enum class LN_NUMBER
{
	LN_W1,
	LN_W2,
	LN_W3,
	LN_W4,
	LN_W5,

	LN_H1,
	LN_H2,
	LN_H3,
	LN_H4,
	LN_H5,

	LN_LT,
	LN_RT,


};

enum  class AIMode
{
	EASY = 1,
	HARD,
};

bool bAcc = true;

void AIModeSetting()
{
	while (true)
	{
		system("cls");
		std::cout << "���Ӹ�� �������ּ���" << std::endl;
		std::cout << "1.EASY" << std::endl;
		std::cout << "2.HARD" << std::endl;

		std::cin >> iSelectMode;

		if (iSelectMode == (int)AIMode::EASY)
		{
			iSelectMode = (int)AIMode::EASY;
			break;
		}
		else if (iSelectMode == (int)AIMode::HARD)
		{
			iSelectMode = (int)AIMode::HARD;
			break;
		}
		else
		{

			continue;
		}

	}
}

void GameSetting()
{
	for (int i = 0; i < 25; ++i)
	{
		Player[i] = i + 1;
		AI[i] = i + 1;
	}


}

void GameShuffle()
{
	int idx1, idx2, itemp;

	for (int i = 0; i < 100; ++i)
	{
		idx1 = rand() % 25;
		idx2 = rand() % 25;

		itemp = Player[idx1];
		Player[idx1] = Player[idx2];
		Player[idx2] = itemp;

		idx1 = rand() % 25;
		idx2 = rand() % 25;

		itemp = AI[idx1];
		AI[idx1] = AI[idx2];
		AI[idx2] = itemp;
	};
}

void PlayerSelectBingo()
{
	for (int i = 0; i < 25; ++i)
	{
		if (Player[i] == iInput)
		{
			Player[i] = INT_MAX;
			bAcc = false;
		}
		if (AI[i] == iInput)
		{
			AI[i] = INT_MAX;
		}
	}
}

void EASYAISelectBingo()
{
	while (true)
	{
		int i = rand() % 25;
		if (AI[i] == INT_MAX)
		{
			continue;
		}
		if (AI[i] != INT_MAX)
		{
			iInput = AI[i];
			break;
		}
	}
	
	

	for (int i = 0; i < 25; ++i)
	{
		if (AI[i] == iInput)
		{
			AI[i] = INT_MAX;
		}
		if (Player[i] == iInput)
		{
			Player[i] = INT_MAX;
		}
	}

}

void LineCheck()
{
	int iStar1, iStar2 = 0;
	int aiStar1, aiStar2 = 0;

	for (int i = 0; i < 5; ++i)
	{
		iStar1 = iStar2 = 0;
		aiStar1 = aiStar2 = 0;


		for (int j = 0; j < 5; ++j)
		{
			if (Player[i * 5 + j] == INT_MAX)
			{
				++iStar1;
			}
			if (AI[i * 5 + j] == INT_MAX)
			{
				++aiStar1;
			}

			if (Player[j * 5 + i] == INT_MAX)
			{
				++iStar2;
			}
			if (AI[j * 5 + i] == INT_MAX)
			{
				++aiStar2;
			}

		}

		if (iStar1 == 5) ++iBingo;
		if (iStar2 == 5) ++iBingo;
		if (aiStar1 == 5) ++iAIBingo;
		if (aiStar2 == 5) ++iAIBingo;


	}

	iStar1 = 0;
	aiStar1 = 0;

	for (int i = 0; i < 25; i += 6)
	{
		if (Player[i] == INT_MAX)
		{
			++iStar1;
		}
		if (AI[i] == INT_MAX)
		{
			++aiStar1;
		}
	}

	if (iStar1 == 5) ++iBingo;

	if (aiStar1 == 5) ++iAIBingo;

	iStar1 = 0;
	aiStar1 = 0;

	for (int i = 4; i <= 20; i += 4)
	{
		if (Player[i] == INT_MAX)
		{
			++iStar1;
		}
		if (AI[i] == INT_MAX)
		{
			++aiStar1;
		}
	}
	if (iStar1 == 5) ++iBingo;

	if (aiStar1 == 5) ++iAIBingo;

}

void HARDAISelectBingo()
{
	int iStartCount = 0;
	int iSaveCount = 0;
	int iLine = 0;

	for (int i = 0; i < 5; ++i)
	{
		iStartCount = 0;

		for (int j = 0; j < 5; ++j)
		{
			if (AI[i * 5 + j] == INT_MAX)
			{
				++iStartCount;
			}
		}

		if (iStartCount < 5 && iSaveCount < iStartCount)
		{
			iLine = i;
			iSaveCount = iStartCount;
		}

	}

	for (int i = 0; i < 5; ++i)
	{
		iStartCount = 0;
		for (int j = 0; j < 5; ++j)
		{
			if (AI[j * 5 + i] == INT_MAX)
			{
				++iStartCount;
			}
		}

		if (iStartCount < 5 && iSaveCount < iStartCount)
		{
			iLine = i + 5;
			iSaveCount = iStartCount;
		}
	}


	iStartCount = 0;

	for (int i = 0; i < 25; i += 6)
	{
		if (AI[i] == INT_MAX)
		{
			++iStartCount;
		}
	}
	if (iStartCount < 5 && iSaveCount < iStartCount)
	{
		iLine = (int)LN_NUMBER::LN_LT;

		iSaveCount = iStartCount;
	}

	iStartCount = 0;

	for (int i = 4; i <= 20; i += 4)
	{
		if (AI[i] == INT_MAX)
		{
			++iStartCount;
		}
	}

	if (iStartCount < 5 && iSaveCount < iStartCount)
	{
		iLine = (int)LN_NUMBER::LN_RT;

		iSaveCount = iStartCount;
	}



	if (iLine < (int)LN_NUMBER::LN_W5)
	{
		for (int i = 0; i < 5; ++i)
		{
			if (AI[iLine * 5 + i] != INT_MAX)
			{
				iInput = AI[iLine * 5 + i];
			}
		}
	}
	else if (iLine < (int)LN_NUMBER::LN_H5)
	{
		for (int i = 0; i < 5; ++i)
		{
			if (AI[i * 5 + (iLine - 5)])
			{
				iInput = AI[i * 5 + (iLine - 5)];
			}
		}
	}
	else if (iLine == (int)LN_NUMBER::LN_LT)
	{
		for (int i = 0; i < 25; i += 6)
		{
			if (AI[i] != INT_MAX)
			{
				iInput = AI[i];
			}
		}
	}
	else if (iLine == (int)LN_NUMBER::LN_RT)
	{
		for (int i = 4; i <= 20; i += 4)
		{
			if (AI[i] != INT_MAX)
			{
				iInput = AI[i];
			}
		}
	}

	for (int i = 0; i < 25; ++i)
	{
		if (iInput == AI[i])
		{
			AI[i] = INT_MAX;
		}
		if (iInput == Player[i])
		{
			Player[i] = INT_MAX;
		}
	}

}


void GameRender()
{
	while (true)
	{
		system("cls");

		std::cout << "Player Bingo ====>" << iBingo << std::endl;
		std::cout << "AIBingo ====>" << iAIBingo << std::endl;

		SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), FOREGROUND_INTENSITY | FOREGROUND_RED | FOREGROUND_GREEN);
		std::cout << "<============Player===========>" << std::endl;
		SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), FOREGROUND_INTENSITY | FOREGROUND_RED | FOREGROUND_BLUE | FOREGROUND_GREEN);
		for (int i = 0; i < 5; ++i)
		{
			for (int j = 0; j < 5; ++j)
			{
				if (Player[i * 5 + j] == INT_MAX)
				{
					SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), FOREGROUND_INTENSITY | FOREGROUND_RED | FOREGROUND_GREEN);
					std::cout << "��" << "\t";
					SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), FOREGROUND_INTENSITY | FOREGROUND_RED | FOREGROUND_BLUE | FOREGROUND_GREEN);
				}
				else
				{
					std::cout << Player[i * 5 + j] << "\t";
				}
			}
			std::cout << std::endl;

		}

		std::cout << std::endl;

		SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), FOREGROUND_INTENSITY | FOREGROUND_RED | FOREGROUND_GREEN);
		std::cout << "<============AI===========>" << std::endl;
		SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), FOREGROUND_INTENSITY | FOREGROUND_RED | FOREGROUND_BLUE | FOREGROUND_GREEN);
		for (int i = 0; i < 5; ++i)
		{
			for (int j = 0; j < 5; ++j)
			{
				if (AI[i * 5 + j] == INT_MAX)
				{
					SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), FOREGROUND_INTENSITY | FOREGROUND_RED | FOREGROUND_GREEN);
					std::cout << "��" << "\t";
					SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), FOREGROUND_INTENSITY | FOREGROUND_RED | FOREGROUND_BLUE | FOREGROUND_GREEN);
				}
				else
				{
					std::cout << AI[i * 5 + j] << "\t";
				}
			}
			std::cout << std::endl;

		}


		std::cout << "��������  -- 99" << std::endl;
		iInput = 0;

		std::cin >> iInput;

		if (iInput == 99)
		{
			std::cout << "Enter�� �����ֽø� ���� ���� �˴ϴ�" << std::endl;
			std::cin.ignore();
			getchar();

			break;
		}

		if (iInput < 1 || iInput>25)
		{
			std::cout << "1~25 ��ȣ�� ����� �Է����ּ��� " << std::endl;
			continue;
		}

		PlayerSelectBingo();

		//�̹� �����Ѱ� �ٽ� �����ϸ� continue�� ������ �ٽ� ������
		if (bAcc) continue;

		switch ((AIMode)iSelectMode)
		{
		case AIMode::EASY:
			EASYAISelectBingo();
			break;
		case AIMode::HARD:
			HARDAISelectBingo();
			break;
		default:
			break;
		}

		iBingo = 0;
		iAIBingo = 0;

		//����üũ
		LineCheck();
	}//while (true)
}




int main()
{
	srand(static_cast<unsigned int>(time(NULL)));

	AIModeSetting();

	GameSetting();

	GameShuffle();

	GameRender();


	return 0;
}